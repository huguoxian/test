create PROCEDURE "test" ( OUT )
AS
BEGIN
	-- routine body goes here, e.g.
	DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
END;
/

